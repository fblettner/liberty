source .venv/bin/activate
rm -r tests/results
python -m tests.main

