source .venv/bin/activate
python -m app.main
