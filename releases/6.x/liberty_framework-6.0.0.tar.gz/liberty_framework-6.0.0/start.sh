source .venv/bin/activate
fastapi dev app/main.py
