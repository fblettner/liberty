AI_ERROR_MESSAGE = "Error fetching AI response "
AI_RESPONSE_DESCRIPTION = "AI response"
AI_RESPONSE_EXAMPLE = {
    "message": "Why did the scarecrow win an award?\n\nBecause he was outstanding in his field!",
    "is_truncated": False
} 

